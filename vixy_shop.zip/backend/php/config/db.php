<?php
/**
 * Vixy Delivery Platform - Conexión de Base de Datos y Helpers
 * Compatible con cPanel, PHP 7.4+, 8.0, 8.1, 8.2, 8.3
 * UTF-8mb4, Prepared Statements y Manejo Seguro de Errores
 */

require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        $host = DB_HOST;
        $port = DB_PORT;
        $dbname = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => true,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];

        try {
            $this->pdo = new PDO($dsn, $user, $pass, $options);
        } catch (PDOException $e) {
            self::jsonResponse([
                'error' => true,
                'mensaje' => 'Error de conexión con la base de datos MySQL en cPanel',
                'detalle' => $e->getMessage()
            ], 500);
            exit();
        }
    }

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance->pdo;
    }

    public static function getRegistConnection(): ?PDO {
        $host = DB_HOST;
        $port = DB_PORT;
        $dbname = defined('REGIST_DB_NAME') ? REGIST_DB_NAME : 'c2861522_regist';
        $user = DB_USER;
        $pass = DB_PASS;
        try {
            $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => true
            ]);
            return $pdo;
        } catch (Exception $e) {
            error_log("Error conectando a BD de registros (c2861522_regist): " . $e->getMessage());
            return null;
        }
    }

    public static function getStoreConnection(): ?PDO {
        $host = DB_HOST;
        $port = DB_PORT;
        $dbname = defined('STORE_DB_NAME') ? STORE_DB_NAME : 'c2861522_vixy_st';
        $user = DB_USER;
        $pass = DB_PASS;
        try {
            $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => true
            ]);
            return $pdo;
        } catch (Exception $e) {
            error_log("Error conectando a BD de tienda (c2861522_vixy_st): " . $e->getMessage());
            return null;
        }
    }

    public static function jsonResponse($data, int $statusCode = 200): void {
        http_response_code($statusCode);
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit();
    }

    public static function getJsonInput(): array {
        $raw = file_get_contents('php://input');
        if (empty($raw)) {
            return [];
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
}
